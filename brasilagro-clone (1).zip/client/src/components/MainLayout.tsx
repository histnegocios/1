import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import { Button } from "@/components/ui/button";
import { Menu, X, LogOut, Instagram, MessageCircle } from "lucide-react";
import { useState, useEffect } from "react";
import { trpc } from "@/lib/trpc";
import { Link } from "wouter";

interface MainLayoutProps {
  children: React.ReactNode;
}

export default function MainLayout({ children }: MainLayoutProps) {
  const { user, logout } = useAuth();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [menuItems, setMenuItems] = useState<any[]>([]);

  const { data: items } = trpc.menu.items.useQuery();

  useEffect(() => {
    if (items) {
      setMenuItems(items);
    }
  }, [items]);

  const handleLogout = async () => {
    await logout();
  };

  return (
    <div className="flex flex-col min-h-screen bg-white">
      {/* Header - Branco com logo aumentada 70% */}
      <header className="bg-white border-b border-gray-300 sticky top-0 z-50 shadow-sm">
        <div className="w-full px-4 sm:px-6 lg:px-8">
          <div className="max-w-7xl mx-auto">
            {/* Top Bar - Apenas Logo */}
            <div className="flex items-center justify-between py-4">
              {/* Logo - Aumentada 70% */}
              <Link href="/">
                <div className="flex items-center gap-2 cursor-pointer">
                  <img
                    src="/manus-storage/conexao-logo_7a15f869.jpg"
                    alt="Conexão Empresarial GO"
                    className="h-28 w-auto"
                    style={{ maxWidth: "270px" }}
                  />
                </div>
              </Link>

              {/* Spacer */}
              <div className="flex-1"></div>

              {/* Mobile Menu Button */}
              <button
                className="md:hidden text-gray-700 p-1"
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              >
                {mobileMenuOpen ? <X size={20} /> : <Menu size={20} />}
              </button>
            </div>

            {/* Navigation Menu - Botões Centralizados com Fundo Branco */}
            <nav className="hidden md:flex items-center justify-center gap-3 py-4 pb-3 flex-wrap">
              <Link href="/">
                <a className="px-4 py-3 bg-white border border-gray-400 rounded text-gray-800 font-bold text-sm hover:bg-gray-50 transition whitespace-nowrap">
                  HOME
                </a>
              </Link>
              {menuItems.map((item) => (
                <Link key={item.id} href={`/${item.slug}`}>
                  <a className="px-4 py-3 bg-white border border-gray-400 rounded text-gray-800 font-bold text-sm hover:bg-gray-50 transition whitespace-nowrap">
                    {item.label}
                  </a>
                </Link>
              ))}
            </nav>

            {/* Mobile Navigation */}
            {mobileMenuOpen && (
              <nav className="md:hidden pb-3 border-t border-gray-300 pt-3">
                <Link href="/">
                  <a className="block px-4 py-2 bg-white border border-gray-400 rounded text-gray-800 font-bold text-sm mb-2 hover:bg-gray-50">HOME</a>
                </Link>
                {menuItems.map((item) => (
                  <Link key={item.id} href={`/${item.slug}`}>
                    <a className="block px-4 py-2 bg-white border border-gray-400 rounded text-gray-800 font-bold text-sm mb-2 hover:bg-gray-50">
                      {item.label}
                    </a>
                  </Link>
                ))}
              </nav>
            )}
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-grow w-full bg-white">
        {children}
      </main>

      {/* Footer - Verde escuro */}
      <footer className="bg-gray-800 text-white mt-16">
        <div className="w-full px-4 sm:px-6 lg:px-8 py-12">
          <div className="max-w-7xl mx-auto">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8 mb-8">
              {/* About */}
              <div>
                <h3 className="text-white font-bold mb-4 text-sm">Sobre</h3>
                <p className="text-gray-400 text-xs leading-relaxed">
                  Portal especializado em cotações do agronegócio em Goiás, com dados em tempo real.
                </p>
              </div>

              {/* Quick Links */}
              <div>
                <h3 className="text-white font-bold mb-4 text-sm">Links</h3>
                <ul className="text-xs space-y-2">
                  <li>
                    <Link href="/">
                      <a className="text-gray-400 hover:text-yellow-400 transition">Home</a>
                    </Link>
                  </li>
                  {menuItems.map((item) => (
                    <li key={item.id}>
                      <Link href={`/${item.slug}`}>
                        <a className="text-gray-400 hover:text-yellow-400 transition">
                          {item.label}
                        </a>
                      </Link>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Categories */}
              <div>
                <h3 className="text-white font-bold mb-4 text-sm">Categorias</h3>
                <ul className="text-xs space-y-2">
                  <li><a href="#" className="text-gray-400 hover:text-yellow-400 transition">Grãos</a></li>
                  <li><a href="#" className="text-gray-400 hover:text-yellow-400 transition">Carnes</a></li>
                  <li><a href="#" className="text-gray-400 hover:text-yellow-400 transition">Leite</a></li>
                  <li><a href="#" className="text-gray-400 hover:text-yellow-400 transition">Máquinas</a></li>
                </ul>
              </div>

              {/* Contact */}
              <div>
                <h3 className="text-white font-bold mb-4 text-sm">Contato</h3>
                <ul className="text-xs text-gray-400 space-y-2">
                  <li>Email: contato@brasilagro.com</li>
                  <li>Telefone: (62) 3000-0000</li>
                  <li>Goiânia, GO</li>
                </ul>
                <div className="flex gap-4 mt-4">
                  <a
                    href="https://instagram.com"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-gray-400 hover:text-pink-500 transition"
                    title="Instagram"
                  >
                    <Instagram size={20} />
                  </a>
                  <a
                    href="https://wa.me/5562999999999"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-gray-400 hover:text-green-500 transition"
                    title="WhatsApp"
                  >
                    <MessageCircle size={20} />
                  </a>
                </div>
              </div>
            </div>

            {/* Copyright */}
            <div className="border-t border-gray-700 pt-6 text-center text-xs text-gray-500">
              <p>&copy; 2026 BrasilAgro. Todos os direitos reservados.</p>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
