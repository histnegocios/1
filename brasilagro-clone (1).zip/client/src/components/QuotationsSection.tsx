import { useEffect, useState } from "react";
import { trpc } from "@/lib/trpc";
import { TrendingUp, TrendingDown } from "lucide-react";

export default function QuotationsSection() {
  const { data: quotations, isLoading } = trpc.quotations.all.useQuery();
  const [displayQuotations, setDisplayQuotations] = useState<any[]>([]);

  useEffect(() => {
    if (quotations) {
      setDisplayQuotations(quotations);
    }
  }, [quotations]);

  if (isLoading) {
    return (
      <div className="bg-green-50 border-t-4 border-[#6BA520] py-6 px-4 sm:px-6">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-lg font-bold text-gray-900 mb-6">Cotações do Dia</h2>
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4">
            {[...Array(6)].map((_, i) => (
              <div key={i} className="bg-white rounded border border-gray-300 p-4 animate-pulse">
                <div className="h-3 bg-gray-300 rounded mb-3"></div>
                <div className="h-6 bg-gray-300 rounded"></div>
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-green-50 border-t-4 border-[#6BA520] py-6 px-4 sm:px-6">
      <div className="max-w-7xl mx-auto">
        <h2 className="text-lg font-bold text-gray-900 mb-6">Cotações do Dia</h2>
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4">
          {displayQuotations.map((quote) => (
            <div
              key={quote.id}
              className="bg-white rounded border border-gray-300 p-4 hover:shadow-md transition-shadow"
            >
              {/* Name */}
              <h3 className="text-xs font-semibold text-gray-700 mb-3 line-clamp-2 h-8 flex items-center">
                {quote.name}
              </h3>

              {/* Value */}
              <div className="flex items-baseline gap-1 mb-3">
                <span className="text-2xl font-bold text-[#6BA520]">{quote.value}</span>
                {quote.unit && <span className="text-xs text-gray-600">{quote.unit}</span>}
              </div>

              {/* Change */}
              {quote.change && (
                <div
                  className={`flex items-center gap-1 text-xs font-bold ${
                    quote.changeType === "up"
                      ? "text-green-600"
                      : quote.changeType === "down"
                      ? "text-red-600"
                      : "text-gray-600"
                  }`}
                >
                  {quote.changeType === "up" && <TrendingUp size={14} />}
                  {quote.changeType === "down" && <TrendingDown size={14} />}
                  <span>{quote.change}</span>
                </div>
              )}

              {/* Time */}
              <p className="text-xs text-gray-500 mt-3 pt-3 border-t border-gray-200">
                {new Date(quote.lastUpdated).toLocaleTimeString("pt-BR", {
                  hour: "2-digit",
                  minute: "2-digit",
                })}
              </p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
