import { useEffect, useState } from "react";
import { trpc } from "@/lib/trpc";
import { ChevronLeft, ChevronRight } from "lucide-react";

export default function NewsCarousel() {
  const { data: news, isLoading } = trpc.news.featured.useQuery();
  const [currentIndex, setCurrentIndex] = useState(0);
  const [displayNews, setDisplayNews] = useState<any[]>([]);

  useEffect(() => {
    if (news && news.length > 0) {
      setDisplayNews(news);
    }
  }, [news]);

  useEffect(() => {
    if (displayNews.length === 0) return;

    const timer = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % displayNews.length);
    }, 5000);

    return () => clearInterval(timer);
  }, [displayNews.length]);

  if (isLoading || displayNews.length === 0) {
    return (
      <div className="w-full" style={{ height: "320px" }}>
        <div className="bg-gradient-to-r from-green-700 to-green-600 flex items-center justify-center h-full">
          <div className="text-white text-center">
            <p className="text-lg font-semibold">Carregando notícias...</p>
          </div>
        </div>
      </div>
    );
  }

  const currentNews = displayNews[currentIndex];

  return (
    <div className="relative w-full overflow-hidden bg-gray-900" style={{ height: "320px" }}>
      {/* Background Image */}
      <div
        className="absolute inset-0 bg-cover bg-center transition-all duration-500"
        style={{
          backgroundImage: currentNews.imageUrl
            ? `url(${currentNews.imageUrl})`
            : "linear-gradient(135deg, rgb(21, 128, 61) 0%, rgb(34, 197, 94) 100%)",
        }}
      >
        <div className="absolute inset-0 bg-black/40"></div>
      </div>

      {/* Content */}
      <div className="absolute inset-0 flex flex-col justify-end p-8">
        <div className="max-w-3xl">
          {currentNews.category && (
            <span className="inline-block bg-yellow-400 text-green-700 px-4 py-2 rounded-full text-sm font-bold mb-4">
              {currentNews.category}
            </span>
          )}
          <h1 className="text-4xl font-bold text-white mb-4 line-clamp-2">
            {currentNews.title}
          </h1>
          {currentNews.description && (
            <p className="text-gray-200 text-base line-clamp-2 mb-6">
              {currentNews.description}
            </p>
          )}
          <button className="bg-yellow-400 text-green-700 px-8 py-3 rounded font-bold hover:bg-yellow-300 transition text-base">
            Leia Mais
          </button>
        </div>
      </div>

      {/* Navigation Buttons */}
      <button
        onClick={() => setCurrentIndex((prev) => (prev - 1 + displayNews.length) % displayNews.length)}
        className="absolute left-6 top-1/2 -translate-y-1/2 bg-white/30 hover:bg-white/50 text-white p-3 rounded-full transition z-10"
      >
        <ChevronLeft size={24} />
      </button>
      <button
        onClick={() => setCurrentIndex((prev) => (prev + 1) % displayNews.length)}
        className="absolute right-6 top-1/2 -translate-y-1/2 bg-white/30 hover:bg-white/50 text-white p-3 rounded-full transition z-10"
      >
        <ChevronRight size={24} />
      </button>

      {/* Indicators */}
      <div className="absolute bottom-6 left-1/2 -translate-x-1/2 flex gap-2 z-10">
        {displayNews.map((_, index) => (
          <button
            key={index}
            onClick={() => setCurrentIndex(index)}
            className={`rounded-full transition ${
              index === currentIndex ? "bg-yellow-400 w-10 h-3" : "bg-white/50 w-3 h-3"
            }`}
          />
        ))}
      </div>
    </div>
  );
}
