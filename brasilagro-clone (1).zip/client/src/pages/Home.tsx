import MainLayout from "@/components/MainLayout";
import QuotationsSection from "@/components/QuotationsSection";
import { trpc } from "@/lib/trpc";
import { useEffect, useState } from "react";
import { Mail, Play } from "lucide-react";

export default function Home() {
  const trackVisitMutation = trpc.visits.track.useMutation();
  const [highlightNews] = useState({
    title: "EUA lançam ofensiva contra JBS, MBRF e mais 2 empresas por suposto cartel",
    image: "https://via.placeholder.com/500x300?text=Noticia+Principal",
    category: "Mercado",
  });

  useEffect(() => {
    const today = new Date().toISOString().split("T")[0];
    const visitorId = localStorage.getItem("visitorId") || generateVisitorId();
    localStorage.setItem("visitorId", visitorId);

    trackVisitMutation.mutate({
      date: today,
      visitorId,
    });
  }, []);

  const newsItems = [
    {
      id: 1,
      title: "Câmara Municipal aprova título de Cidadão Araraquarense a Paulo Junqueira",
      category: "Política",
      image: "https://via.placeholder.com/300x200?text=Noticia+1",
    },
    {
      id: 2,
      title: "Com oferta menor, preço do leite sobe 18% no 1º trimestre no campo",
      category: "Leite",
      image: "https://via.placeholder.com/300x200?text=Noticia+2",
    },
    {
      id: 3,
      title: "Alta do diesel gera prejuízo de R$ 7,2 bilhões ao agronegócio",
      category: "Mercado",
      image: "https://via.placeholder.com/300x200?text=Noticia+3",
    },
    {
      id: 4,
      title: "Biocombustíveis: Adicionarão até R$ 403 bi ao PIB e gerar 225 mil empregos",
      category: "Energia",
      image: "https://via.placeholder.com/300x200?text=Noticia+4",
    },
    {
      id: 5,
      title: "Exportação de carne bovina pode cair 10% em 2026 com restrição da China",
      category: "Carnes",
      image: "https://via.placeholder.com/300x200?text=Noticia+5",
    },
    {
      id: 6,
      title: "Canadá: Produtores dizem que acordo com Mercosul vai devastar a indústria",
      category: "Comércio",
      image: "https://via.placeholder.com/300x200?text=Noticia+6",
    },
  ];

  return (
    <MainLayout>
      {/* Quotations Section */}
      <QuotationsSection />

      {/* Main Content Area */}
      <div className="px-4 sm:px-6 lg:px-8 py-6">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
            {/* Sidebar Esquerdo */}
            <aside className="lg:col-span-1">
              {/* TV Section */}
              <div className="mb-8">
                <h3 className="text-sm font-bold text-[#6BA520] mb-4 border-b-2 border-[#6BA520] pb-2">
                  TV BRASILAGRO
                </h3>
                <div className="bg-gray-200 rounded aspect-video flex items-center justify-center mb-4">
                  <Play className="text-white" size={48} />
                </div>
                <p className="text-xs text-gray-700 font-semibold mb-3">
                  TV BrasilAgro – Programa nº 483 - Os 11 vídeos proibidos pelo ministro Alexandre de Moraes
                </p>
                <button className="w-full bg-[#6BA520] text-white py-2 rounded font-bold text-xs hover:bg-green-700 transition">
                  VÍDEOS ANTERIORES
                </button>
              </div>

              {/* Newsletter Section */}
              <div className="bg-gray-50 rounded p-4 border border-gray-300">
                <h3 className="text-sm font-bold text-gray-900 mb-4">Newsletter</h3>
                <input
                  type="text"
                  placeholder="Nome"
                  className="w-full px-3 py-2 border border-gray-300 rounded text-xs mb-3 focus:outline-none focus:ring-2 focus:ring-[#6BA520]"
                />
                <input
                  type="email"
                  placeholder="Email"
                  className="w-full px-3 py-2 border border-gray-300 rounded text-xs mb-4 focus:outline-none focus:ring-2 focus:ring-[#6BA520]"
                />
                <button className="w-full bg-[#6BA520] text-white py-2 rounded font-bold text-xs hover:bg-green-700 transition flex items-center justify-center gap-2">
                  <Mail size={14} />
                  CADASTRAR
                </button>
              </div>
            </aside>

            {/* Main Content - 3 Columns */}
            <div className="lg:col-span-3">
              {/* Highlight News */}
              <div className="mb-8 bg-white rounded border border-gray-300 overflow-hidden hover:shadow-lg transition">
                <img
                  src={highlightNews.image}
                  alt={highlightNews.title}
                  className="w-full h-64 object-cover"
                />
                <div className="p-4">
                  <span className="text-xs font-bold text-[#6BA520] bg-green-50 px-2 py-1 rounded">
                    {highlightNews.category}
                  </span>
                  <h2 className="text-lg font-bold text-gray-900 mt-2 line-clamp-3">
                    {highlightNews.title}
                  </h2>
                </div>
              </div>

              {/* News Grid - 3 Columns */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                {newsItems.map((news) => (
                  <div
                    key={news.id}
                    className="bg-white rounded border border-gray-300 overflow-hidden hover:shadow-lg transition cursor-pointer"
                  >
                    <img
                      src={news.image}
                      alt={news.title}
                      className="w-full h-40 object-cover"
                    />
                    <div className="p-4">
                      <span className="text-xs font-bold text-[#6BA520] bg-green-50 px-2 py-1 rounded">
                        {news.category}
                      </span>
                      <h3 className="text-sm font-bold text-gray-900 mt-2 line-clamp-3">
                        {news.title}
                      </h3>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </MainLayout>
  );
}

function generateVisitorId(): string {
  return `visitor_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
}
