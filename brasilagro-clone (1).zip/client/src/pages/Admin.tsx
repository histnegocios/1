import { useAuth } from "@/_core/hooks/useAuth";
import MainLayout from "@/components/MainLayout";
import { Button } from "@/components/ui/button";
import { trpc } from "@/lib/trpc";
import { useEffect, useState } from "react";
import { useLocation } from "wouter";

export default function Admin() {
  const { user } = useAuth();
  const [, navigate] = useLocation();
  const [activeTab, setActiveTab] = useState("dashboard");
  const [menuItems, setMenuItems] = useState<any[]>([]);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [editingLabel, setEditingLabel] = useState("");
  const [visitStats, setVisitStats] = useState<any>(null);

  const { data: items } = trpc.menu.items.useQuery();
  const { data: todayVisits } = trpc.visits.today.useQuery();
  const updateMenuMutation = trpc.menu.update.useMutation();

  useEffect(() => {
    if (!user || user.role !== "admin") {
      navigate("/");
    }
  }, [user, navigate]);

  useEffect(() => {
    if (items) {
      setMenuItems(items);
    }
  }, [items]);

  useEffect(() => {
    if (todayVisits) {
      setVisitStats(todayVisits);
    }
  }, [todayVisits]);

  const handleUpdateMenu = async (id: number, newLabel: string) => {
    try {
      await updateMenuMutation.mutateAsync({ id, label: newLabel });
      setEditingId(null);
      setEditingLabel("");
      if (items) {
        const updated = items.map((item) =>
          item.id === id ? { ...item, label: newLabel } : item
        );
        setMenuItems(updated);
      }
    } catch (error) {
      console.error("Failed to update menu:", error);
    }
  };

  if (!user || user.role !== "admin") {
    return null;
  }

  const isDashboard = activeTab === "dashboard";
  const isMenu = activeTab === "menu";
  const isVisits = activeTab === "visits";

  return (
    <MainLayout>
      <div className="w-full px-3 sm:px-4 py-6 sm:py-8">
        <div className="max-w-7xl mx-auto">
          <h1 className="text-2xl sm:text-3xl font-bold text-gray-900 mb-6 sm:mb-8">Painel Administrativo</h1>

          <div className="flex gap-2 sm:gap-4 mb-6 sm:mb-8 border-b border-gray-200 overflow-x-auto">
            <button
              onClick={() => setActiveTab("dashboard")}
              className={`px-3 sm:px-4 py-2 font-semibold border-b-2 transition text-sm sm:text-base whitespace-nowrap ${
                isDashboard
                  ? "border-green-700 text-green-700"
                  : "border-transparent text-gray-600 hover:text-gray-900"
              }`}
            >
              Dashboard
            </button>
            <button
              onClick={() => setActiveTab("menu")}
              className={`px-3 sm:px-4 py-2 font-semibold border-b-2 transition text-sm sm:text-base whitespace-nowrap ${
                isMenu
                  ? "border-green-700 text-green-700"
                  : "border-transparent text-gray-600 hover:text-gray-900"
              }`}
            >
              Gerenciar Menu
            </button>
            <button
              onClick={() => setActiveTab("visits")}
              className={`px-3 sm:px-4 py-2 font-semibold border-b-2 transition text-sm sm:text-base whitespace-nowrap ${
                isVisits
                  ? "border-green-700 text-green-700"
                  : "border-transparent text-gray-600 hover:text-gray-900"
              }`}
            >
              Visitas
            </button>
          </div>

          {isDashboard && (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
              <div className="bg-white rounded-lg shadow p-4 sm:p-6">
                <h3 className="text-gray-600 font-semibold mb-2 text-sm sm:text-base">Visitas Hoje</h3>
                <p className="text-2xl sm:text-3xl font-bold text-green-700">
                  {visitStats?.totalVisits || 0}
                </p>
              </div>
              <div className="bg-white rounded-lg shadow p-4 sm:p-6">
                <h3 className="text-gray-600 font-semibold mb-2 text-sm sm:text-base">Visitantes Unicos</h3>
                <p className="text-2xl sm:text-3xl font-bold text-green-700">
                  {visitStats?.uniqueVisits || 0}
                </p>
              </div>
              <div className="bg-white rounded-lg shadow p-4 sm:p-6">
                <h3 className="text-gray-600 font-semibold mb-2 text-sm sm:text-base">Itens do Menu</h3>
                <p className="text-2xl sm:text-3xl font-bold text-green-700">{menuItems.length}</p>
              </div>
            </div>
          )}

          {isMenu && (
            <div className="bg-white rounded-lg shadow p-4 sm:p-6">
              <h2 className="text-lg sm:text-xl font-bold text-gray-900 mb-4 sm:mb-6">Gerenciar Itens do Menu</h2>
              <div className="space-y-3 sm:space-y-4">
                {menuItems.map((item) => (
                  <div key={item.id} className="flex flex-col sm:flex-row sm:items-center gap-3 sm:gap-4 p-3 sm:p-4 border border-gray-200 rounded-lg">
                    <div className="flex-grow min-w-0">
                      {editingId === item.id ? (
                        <input
                          type="text"
                          value={editingLabel}
                          onChange={(e) => setEditingLabel(e.target.value)}
                          className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-700 text-sm"
                        />
                      ) : (
                        <div>
                          <p className="font-semibold text-gray-900 text-sm sm:text-base">{item.label}</p>
                          <p className="text-xs sm:text-sm text-gray-600">Slug: {item.slug}</p>
                        </div>
                      )}
                    </div>
                    <div className="flex gap-2 flex-shrink-0">
                      {editingId === item.id ? (
                        <>
                          <Button
                            size="sm"
                            className="bg-green-700 hover:bg-green-600 text-xs sm:text-sm"
                            onClick={() => handleUpdateMenu(item.id, editingLabel)}
                          >
                            Salvar
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            className="text-xs sm:text-sm"
                            onClick={() => setEditingId(null)}
                          >
                            Cancelar
                          </Button>
                        </>
                      ) : (
                        <Button
                          size="sm"
                          variant="outline"
                          className="text-xs sm:text-sm"
                          onClick={() => {
                            setEditingId(item.id);
                            setEditingLabel(item.label);
                          }}
                        >
                          Editar
                        </Button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {isVisits && (
            <div className="bg-white rounded-lg shadow p-4 sm:p-6">
              <h2 className="text-lg sm:text-xl font-bold text-gray-900 mb-4 sm:mb-6">Estatisticas de Visitas</h2>
              {visitStats ? (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 sm:gap-6">
                  <div className="p-4 sm:p-6 bg-green-50 rounded-lg border border-green-200">
                    <p className="text-gray-600 font-semibold mb-2 text-sm sm:text-base">Total de Visitas Hoje</p>
                    <p className="text-3xl sm:text-4xl font-bold text-green-700">{visitStats.totalVisits}</p>
                  </div>
                  <div className="p-4 sm:p-6 bg-blue-50 rounded-lg border border-blue-200">
                    <p className="text-gray-600 font-semibold mb-2 text-sm sm:text-base">Visitantes Unicos Hoje</p>
                    <p className="text-3xl sm:text-4xl font-bold text-blue-700">{visitStats.uniqueVisits}</p>
                  </div>
                </div>
              ) : (
                <p className="text-gray-600 text-sm">Nenhum dado de visitas disponivel para hoje.</p>
              )}
            </div>
          )}
        </div>
      </div>
    </MainLayout>
  );
}
