import { int, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Notícias do portal
 */
export const news = mysqlTable("news", {
  id: int("id").autoincrement().primaryKey(),
  title: text("title").notNull(),
  description: text("description"),
  content: text("content"),
  imageUrl: text("imageUrl"),
  category: varchar("category", { length: 64 }),
  featured: int("featured").default(0).notNull(), // 0 = false, 1 = true
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type News = typeof news.$inferSelect;
export type InsertNews = typeof news.$inferInsert;

/**
 * Cotações de produtos agrícolas e moedas
 */
export const quotations = mysqlTable("quotations", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 128 }).notNull(), // Ex: "Dólar", "Bitcoin", "Boi (Goiás)"
  value: varchar("value", { length: 64 }).notNull(), // Valor formatado
  unit: varchar("unit", { length: 32 }), // Ex: "BRL", "@", "sc"
  change: varchar("change", { length: 32 }), // Variação (ex: "+1.5%")
  changeType: mysqlEnum("changeType", ["up", "down", "neutral"]).default("neutral"),
  lastUpdated: timestamp("lastUpdated").defaultNow().onUpdateNow().notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Quotation = typeof quotations.$inferSelect;
export type InsertQuotation = typeof quotations.$inferInsert;

/**
 * Itens do menu de navegação
 */
export const menuItems = mysqlTable("menuItems", {
  id: int("id").autoincrement().primaryKey(),
  label: varchar("label", { length: 128 }).notNull(), // Nome exibido (ex: "Home", "Editorias")
  slug: varchar("slug", { length: 128 }).notNull().unique(), // Identificador único (ex: "home", "editorias")
  order: int("order").notNull(), // Ordem de exibição
  isActive: int("isActive").default(1).notNull(), // 0 = inativo, 1 = ativo
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type MenuItem = typeof menuItems.$inferSelect;
export type InsertMenuItem = typeof menuItems.$inferInsert;

/**
 * Registro de visitas diárias
 */
export const dailyVisits = mysqlTable("dailyVisits", {
  id: int("id").autoincrement().primaryKey(),
  date: varchar("date", { length: 10 }).notNull().unique(), // Formato: YYYY-MM-DD
  totalVisits: int("totalVisits").default(0).notNull(),
  uniqueVisits: int("uniqueVisits").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type DailyVisit = typeof dailyVisits.$inferSelect;
export type InsertDailyVisit = typeof dailyVisits.$inferInsert;

/**
 * Rastreamento de visitantes únicos (por IP/sessão)
 */
export const visitors = mysqlTable("visitors", {
  id: int("id").autoincrement().primaryKey(),
  visitorId: varchar("visitorId", { length: 128 }).notNull(), // Hash de IP ou session ID
  date: varchar("date", { length: 10 }).notNull(), // Formato: YYYY-MM-DD
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

// Criar indice unico para visitorId + date para garantir granularidade diaria
// ALTER TABLE visitors ADD UNIQUE KEY unique_visitor_date (visitorId, date);

export type Visitor = typeof visitors.$inferSelect;
export type InsertVisitor = typeof visitors.$inferInsert;