import { drizzle } from "drizzle-orm/mysql2";
import { menuItems, quotations, news } from "./drizzle/schema.ts";

const db = drizzle(process.env.DATABASE_URL);

async function seedDatabase() {
  try {
    console.log("Iniciando populacao do banco de dados...");

    // Insert menu items
    console.log("Inserindo itens do menu...");
    await db.insert(menuItems).values([
      { label: "Home", slug: "home", order: 1, isActive: 1 },
      { label: "Editorias", slug: "editorias", order: 2, isActive: 1 },
      { label: "Guia de Fornecedores", slug: "guia-fornecedores", order: 3, isActive: 1 },
      { label: "TV", slug: "tv", order: 4, isActive: 1 },
      { label: "Eventos", slug: "eventos", order: 5, isActive: 1 },
      { label: "Anuncie", slug: "anuncie", order: 6, isActive: 1 },
      { label: "Contato", slug: "contato", order: 7, isActive: 1 },
    ]);

    // Insert quotations
    console.log("Inserindo cotacoes...");
    await db.insert(quotations).values([
      {
        name: "Dolar",
        value: "4.95",
        unit: "BRL",
        change: "-0.5%",
        changeType: "down",
      },
      {
        name: "Bitcoin",
        value: "68.500",
        unit: "BRL",
        change: "+2.3%",
        changeType: "up",
      },
      {
        name: "Arroba do Boi (Goias)",
        value: "185.50",
        unit: "@",
        change: "+1.2%",
        changeType: "up",
      },
      {
        name: "Saca da Soja (Goias)",
        value: "62.80",
        unit: "sc",
        change: "-0.8%",
        changeType: "down",
      },
      {
        name: "Saca do Milho (Goias)",
        value: "45.30",
        unit: "sc",
        change: "+0.3%",
        changeType: "up",
      },
      {
        name: "Saca do Cafe (Goias)",
        value: "720.00",
        unit: "sc",
        change: "+1.5%",
        changeType: "up",
      },
    ]);

    // Insert news
    console.log("Inserindo noticias...");
    await db.insert(news).values([
      {
        title: "Producao de soja em Goias cresce 15% nesta safra",
        description: "Dados preliminares indicam aumento significativo na producao de soja no estado de Goias.",
        content: "A producao de soja em Goias apresenta crescimento de 15% nesta safra, segundo relatorio preliminar da CONAB.",
        category: "Graos",
        featured: 1,
      },
      {
        title: "Preco do boi sobe no mercado de Goias",
        description: "Arroba do boi atinge novo patamar no estado, impulsionada pela demanda internacional.",
        content: "O preco da arroba do boi em Goias subiu para R$ 185,50, refletindo a forte demanda do mercado internacional.",
        category: "Carnes",
        featured: 1,
      },
      {
        title: "Tecnologia digital transforma agronegocio",
        description: "Startups de agtech apresentam solucoes inovadoras para o setor agricola.",
        content: "Empresas de tecnologia agricola apresentam novas solucoes para aumentar a produtividade e reduzir custos.",
        category: "Agrotech",
        featured: 1,
      },
      {
        title: "Sustentabilidade no agronegocio brasileiro",
        description: "Produtores adotam praticas sustentaveis para preservar o meio ambiente.",
        content: "Cada vez mais produtores rurais adotam praticas sustentaveis em suas operacoes.",
        category: "Meio Ambiente",
        featured: 1,
      },
      {
        title: "Exportacoes de cafe brasileiro crescem",
        description: "Brasil aumenta suas exportacoes de cafe para mercados internacionais.",
        content: "As exportacoes de cafe brasileiro crescem significativamente nos ultimos meses.",
        category: "Cafe",
        featured: 0,
      },
    ]);

    console.log("Banco de dados populado com sucesso!");
    process.exit(0);
  } catch (error) {
    console.error("Erro ao popular banco de dados:", error);
    process.exit(1);
  }
}

seedDatabase();
