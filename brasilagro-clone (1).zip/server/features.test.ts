import { describe, expect, it, beforeAll, afterAll } from "vitest";
import { getDb } from "./db";
import { menuItems, quotations, dailyVisits, visitors } from "../drizzle/schema";
import { eq } from "drizzle-orm";

let db: any;

beforeAll(async () => {
  db = await getDb();
});

describe("Menu Items", () => {
  it("should fetch menu items", async () => {
    if (!db) {
      console.warn("Database not available");
      return;
    }

    const items = await db.select().from(menuItems).limit(5);
    expect(items.length).toBeGreaterThan(0);
    expect(items[0]).toHaveProperty("label");
    expect(items[0]).toHaveProperty("slug");
  });

  it("should have correct menu item structure", async () => {
    if (!db) return;

    const items = await db.select().from(menuItems).limit(1);
    expect(items[0]).toMatchObject({
      id: expect.any(Number),
      label: expect.any(String),
      slug: expect.any(String),
      order: expect.any(Number),
      isActive: expect.any(Number),
    });
  });
});

describe("Quotations", () => {
  it("should fetch quotations", async () => {
    if (!db) return;

    const quotes = await db.select().from(quotations);
    expect(quotes.length).toBeGreaterThanOrEqual(6);
  });

  it("should have all required quotations", async () => {
    if (!db) return;

    const quotes = await db.select().from(quotations);
    const names = quotes.map((q: any) => q.name);

    expect(names).toContain("Dolar");
    expect(names).toContain("Bitcoin");
    expect(names).toContain("Arroba do Boi (Goias)");
    expect(names).toContain("Saca da Soja (Goias)");
    expect(names).toContain("Saca do Milho (Goias)");
    expect(names).toContain("Saca do Cafe (Goias)");
  });

  it("should have valid quotation structure", async () => {
    if (!db) return;

    const quotes = await db.select().from(quotations).limit(1);
    expect(quotes[0]).toMatchObject({
      id: expect.any(Number),
      name: expect.any(String),
      value: expect.any(String),
      unit: expect.any(String),
      changeType: expect.stringMatching(/^(up|down|neutral)$/),
    });
  });
});

describe("Daily Visits", () => {
  it("should create daily visit record", async () => {
    if (!db) return;

    const today = new Date().toISOString().split("T")[0];
    const visitorId = `test_visitor_${Date.now()}`;

    // Insert visitor
    await db.insert(visitors).values({ visitorId, date: today });

    // Check if visitor was inserted
    const visitor = await db
      .select()
      .from(visitors)
      .where(eq(visitors.visitorId, visitorId))
      .limit(1);

    expect(visitor.length).toBe(1);
    expect(visitor[0].date).toBe(today);
  });

  it("should track daily visits", async () => {
    if (!db) return;

    const today = new Date().toISOString().split("T")[0];

    // Get or create daily visit
    let dayVisit = await db
      .select()
      .from(dailyVisits)
      .where(eq(dailyVisits.date, today))
      .limit(1);

    if (dayVisit.length === 0) {
      await db.insert(dailyVisits).values({
        date: today,
        totalVisits: 1,
        uniqueVisits: 1,
      });
      dayVisit = await db
        .select()
        .from(dailyVisits)
        .where(eq(dailyVisits.date, today))
        .limit(1);
    }

    expect(dayVisit[0]).toHaveProperty("totalVisits");
    expect(dayVisit[0]).toHaveProperty("uniqueVisits");
    expect(dayVisit[0].totalVisits).toBeGreaterThanOrEqual(1);
  });
});

describe("News", () => {
  it("should have news data in database", async () => {
    if (!db) return;

    const { news } = await import("../drizzle/schema");
    const newsItems = await db.select().from(news).limit(5);

    expect(newsItems.length).toBeGreaterThan(0);
    expect(newsItems[0]).toHaveProperty("title");
    expect(newsItems[0]).toHaveProperty("category");
  });
});
