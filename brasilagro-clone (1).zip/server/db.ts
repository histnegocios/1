import { and, eq, gte, lte } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, users, news, menuItems, quotations, dailyVisits, visitors } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

// Notícias
export async function getFeaturedNews() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(news).where(eq(news.featured, 1)).limit(5);
}

export async function getAllNews(limit = 20, offset = 0) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(news).limit(limit).offset(offset);
}

// Menu Items
export async function getMenuItems() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(menuItems).where(eq(menuItems.isActive, 1)).orderBy(menuItems.order);
}

export async function updateMenuItem(id: number, label: string) {
  const db = await getDb();
  if (!db) return null;
  await db.update(menuItems).set({ label, updatedAt: new Date() }).where(eq(menuItems.id, id));
  return db.select().from(menuItems).where(eq(menuItems.id, id)).limit(1);
}

// Quotations
export async function getQuotations() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(quotations);
}

export async function updateQuotation(id: number, value: string, change: string, changeType: 'up' | 'down' | 'neutral') {
  const db = await getDb();
  if (!db) return null;
  await db.update(quotations).set({ value, change, changeType, lastUpdated: new Date() }).where(eq(quotations.id, id));
  return db.select().from(quotations).where(eq(quotations.id, id)).limit(1);
}

// Daily Visits
export async function getDailyVisits(date: string) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.select().from(dailyVisits).where(eq(dailyVisits.date, date)).limit(1);
  return result.length > 0 ? result[0] : null;
}

export async function incrementVisits(date: string, visitorId: string) {
  const db = await getDb();
  if (!db) return null;

  // Check if visitor already visited today
  const existingVisitor = await db.select().from(visitors).where(
    and(eq(visitors.date, date), eq(visitors.visitorId, visitorId))
  ).limit(1);

  const isNewVisitor = existingVisitor.length === 0;

  // Insert visitor record if new
  if (isNewVisitor) {
    await db.insert(visitors).values({ visitorId, date });
  }

  // Get or create daily visit record
  let dailyVisit = await getDailyVisits(date);
  if (!dailyVisit) {
    await db.insert(dailyVisits).values({ date, totalVisits: 1, uniqueVisits: isNewVisitor ? 1 : 0 });
  } else {
    const increment = isNewVisitor ? { totalVisits: dailyVisit.totalVisits + 1, uniqueVisits: dailyVisit.uniqueVisits + 1 } : { totalVisits: dailyVisit.totalVisits + 1 };
    await db.update(dailyVisits).set({ ...increment, updatedAt: new Date() }).where(eq(dailyVisits.date, date));
  }

  return getDailyVisits(date);
}

export async function getVisitStats(startDate: string, endDate: string) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(dailyVisits).where(
    and(gte(dailyVisits.date, startDate), lte(dailyVisits.date, endDate))
  ).orderBy(dailyVisits.date);
}


