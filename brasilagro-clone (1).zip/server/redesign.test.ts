import { describe, expect, it, beforeAll } from "vitest";
import { getDb } from "./db";
import { quotations } from "../drizzle/schema";

let db: any;

beforeAll(async () => {
  db = await getDb();
});

describe("Redesign Validation", () => {
  it("should have exactly 6 quotation types", async () => {
    if (!db) {
      console.warn("Database not available");
      return;
    }

    const quotes = await db.select().from(quotations);
    expect(quotes.length).toBe(6);

    const requiredNames = [
      "Dolar",
      "Bitcoin",
      "Arroba do Boi (Goias)",
      "Saca da Soja (Goias)",
      "Saca do Milho (Goias)",
      "Saca do Cafe (Goias)",
    ];

    const quoteNames = quotes.map((q: any) => q.name);
    requiredNames.forEach((name) => {
      expect(quoteNames).toContain(name);
    });
  });

  it("should have all quotations with required fields", async () => {
    if (!db) return;

    const quotes = await db.select().from(quotations);

    quotes.forEach((quote: any) => {
      expect(quote.id).toBeDefined();
      expect(quote.name).toBeDefined();
      expect(quote.value).toBeDefined();
      expect(quote.unit).toBeDefined();
      expect(quote.change).toBeDefined();
      expect(quote.changeType).toMatch(/^(up|down|neutral)$/);
      expect(quote.lastUpdated).toBeDefined();
    });
  });

  it("should have valid quotation values", async () => {
    if (!db) return;

    const quotes = await db.select().from(quotations);

    quotes.forEach((quote: any) => {
      const value = parseFloat(quote.value);
      expect(value).toBeGreaterThan(0);
    });
  });

  it("should have valid change percentages", async () => {
    if (!db) return;

    const quotes = await db.select().from(quotations);

    quotes.forEach((quote: any) => {
      const changeMatch = quote.change.match(/^([+-]?\d+\.?\d*)%$/);
      expect(changeMatch).toBeDefined();
    });
  });
});
