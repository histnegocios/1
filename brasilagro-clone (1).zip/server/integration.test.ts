import { describe, expect, it, beforeAll } from "vitest";
import { getDb } from "./db";
import { incrementVisits, getDailyVisits, updateMenuItem } from "./db";
import { menuItems } from "../drizzle/schema";
import { eq } from "drizzle-orm";

let db: any;

beforeAll(async () => {
  db = await getDb();
});

describe("Visit Tracking Integration", () => {
  it("should track visits with daily granularity", async () => {
    if (!db) {
      console.warn("Database not available");
      return;
    }

    const today = new Date().toISOString().split("T")[0];
    const visitorId1 = `test_visitor_${Date.now()}_1`;
    const visitorId2 = `test_visitor_${Date.now()}_2`;

    // First visit from visitor 1
    const result1 = await incrementVisits(today, visitorId1);
    expect(result1).toBeDefined();
    expect(result1?.totalVisits).toBeGreaterThan(0);
    expect(result1?.uniqueVisits).toBeGreaterThan(0);
    const firstTotal = result1?.totalVisits || 0;
    const firstUnique = result1?.uniqueVisits || 0;

    // Second visit from visitor 1 (same day)
    const result2 = await incrementVisits(today, visitorId1);
    expect(result2?.totalVisits).toBe(firstTotal + 1);
    expect(result2?.uniqueVisits).toBe(firstUnique);

    // First visit from visitor 2 (same day)
    const result3 = await incrementVisits(today, visitorId2);
    expect(result3?.totalVisits).toBe(firstTotal + 2);
    expect(result3?.uniqueVisits).toBe(firstUnique + 1);
  });

  it("should handle multiple days separately", async () => {
    if (!db) return;

    const today = new Date().toISOString().split("T")[0];
    const tomorrow = new Date(Date.now() + 86400000).toISOString().split("T")[0];
    const visitorId = `test_visitor_${Date.now()}_multiday`;

    // Visit today
    const todayVisit = await incrementVisits(today, visitorId);
    expect(todayVisit?.date).toBe(today);

    // Visit tomorrow
    const tomorrowVisit = await incrementVisits(tomorrow, visitorId);
    expect(tomorrowVisit?.date).toBe(tomorrow);

    // Both should have separate records
    expect(todayVisit?.date).not.toBe(tomorrowVisit?.date);
  });
});

describe("Menu Management Integration", () => {
  it("should update menu item label", async () => {
    if (!db) return;

    // Get first menu item
    const items = await db.select().from(menuItems).limit(1);
    if (items.length === 0) return;

    const originalLabel = items[0].label;
    const newLabel = `Updated_${Date.now()}`;

    // Update menu item
    const result = await updateMenuItem(items[0].id, newLabel);
    expect(result).toBeDefined();
    expect(result?.[0]?.label).toBe(newLabel);

    // Verify update persisted
    const updated = await db
      .select()
      .from(menuItems)
      .where(eq(menuItems.id, items[0].id))
      .limit(1);
    expect(updated[0].label).toBe(newLabel);

    // Restore original label
    await updateMenuItem(items[0].id, originalLabel);
  });
});

describe("Quotations", () => {
  it("should have all required quotation types", async () => {
    if (!db) return;

    const { quotations } = await import("../drizzle/schema");
    const quotes = await db.select().from(quotations);

    const requiredNames = [
      "Dolar",
      "Bitcoin",
      "Arroba do Boi (Goias)",
      "Saca da Soja (Goias)",
      "Saca do Milho (Goias)",
      "Saca do Cafe (Goias)",
    ];

    const quoteNames = quotes.map((q: any) => q.name);
    requiredNames.forEach((name) => {
      expect(quoteNames).toContain(name);
    });
  });
});
