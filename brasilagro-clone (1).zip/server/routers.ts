import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";

export const appRouter = router({
    // if you need to use socket.io, read and register route in server/_core/index.ts, all api should start with '/api/' so that the gateway can route correctly
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  // Notícias
  news: router({
    featured: publicProcedure.query(async () => {
      const { getFeaturedNews } = await import('./db');
      return getFeaturedNews();
    }),
    all: publicProcedure.query(async () => {
      const { getAllNews } = await import('./db');
      return getAllNews();
    }),
  }),

  // Menu
  menu: router({
    items: publicProcedure.query(async () => {
      const { getMenuItems } = await import('./db');
      return getMenuItems();
    }),
    update: protectedProcedure
      .input((input: any) => input)
      .mutation(async ({ input, ctx }) => {
        if (ctx.user?.role !== 'admin') {
          throw new Error('Unauthorized');
        }
        const { updateMenuItem } = await import('./db');
        return updateMenuItem(input.id, input.label);
      }),
  }),

  // Cotações
  quotations: router({
    all: publicProcedure.query(async () => {
      const { getQuotations } = await import('./db');
      return getQuotations();
    }),
    update: protectedProcedure
      .input((input: any) => input)
      .mutation(async ({ input, ctx }) => {
        if (ctx.user?.role !== 'admin') {
          throw new Error('Unauthorized');
        }
        const { updateQuotation } = await import('./db');
        return updateQuotation(input.id, input.value, input.change, input.changeType);
      }),
  }),

  // Visitas
  visits: router({
    track: publicProcedure
      .input((input: any) => input)
      .mutation(async ({ input }) => {
        const { incrementVisits } = await import('./db');
        return incrementVisits(input.date, input.visitorId);
      }),
    stats: protectedProcedure
      .input((input: any) => input)
      .query(async ({ input, ctx }) => {
        if (ctx.user?.role !== 'admin') {
          throw new Error('Unauthorized');
        }
        const { getVisitStats } = await import('./db');
        return getVisitStats(input.startDate, input.endDate);
      }),
    today: protectedProcedure.query(async ({ ctx }) => {
      if (ctx.user?.role !== 'admin') {
        throw new Error('Unauthorized');
      }
      const { getDailyVisits } = await import('./db');
      const today = new Date().toISOString().split('T')[0];
      return getDailyVisits(today);
    }),
  }),
});

export type AppRouter = typeof appRouter;
